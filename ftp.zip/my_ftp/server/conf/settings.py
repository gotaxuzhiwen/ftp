import os


base_path = os.path.dirname(os.path.dirname(__file__))
userinfo = os.path.join(base_path,'db','userinfo')